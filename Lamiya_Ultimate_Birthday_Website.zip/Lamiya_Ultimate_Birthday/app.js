const {useState,useEffect} = React;

const photos = [
  {src:"images/lamiya-1.jpg",caption:"Your smile is my favourite view"},
  {src:"images/lamiya-2.jpg",caption:"A little elegance, a lot of magic"},
  {src:"images/lamiya-3.jpg",caption:"The kind of beauty words cannot explain"},
  {src:"images/lamiya-4.jpg",caption:"A smile that makes the day brighter"},
  {src:"images/lamiya-5.jpg",caption:"Forever a favourite picture"}
];

function App(){
  const [light,setLight]=useState(false);
  const [music,setMusic]=useState(false);
  const [modal,setModal]=useState(null);
  const [toast,setToast]=useState("");
  const [gift,setGift]=useState(false);
  const [answer,setAnswer]=useState("");
  const [seconds,setSeconds]=useState({d:"00",h:"00",m:"00",s:"00"});
  const [letterOpen,setLetterOpen]=useState(false);

  useEffect(()=>{
    document.body.classList.toggle("light",light);
    const obs=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");obs.unobserve(e.target)}}),{threshold:.12});
    document.querySelectorAll(".reveal").forEach(el=>obs.observe(el));
    return ()=>obs.disconnect();
  },[light]);

  useEffect(()=>{
    const tick=()=>{
      const now=new Date(), target=new Date(now.getFullYear(),10,14,0,0,0);
      if(now>target) target.setFullYear(target.getFullYear()+1);
      const diff=Math.max(0,target-now);
      setSeconds({d:String(Math.floor(diff/86400000)).padStart(2,"0"),h:String(Math.floor(diff/3600000)%24).padStart(2,"0"),m:String(Math.floor(diff/60000)%60).padStart(2,"0"),s:String(Math.floor(diff/1000)%60).padStart(2,"0")});
    };
    tick();const id=setInterval(tick,1000);return ()=>clearInterval(id);
  },[]);

  const notify=(msg)=>{setToast(msg);setTimeout(()=>setToast(""),2400)};
  const rain=(count=45)=>{for(let i=0;i<count;i++){const el=document.createElement("span");el.className="heart-rain";el.textContent=["💗","💕","💖","✨","🌸","💝"][Math.floor(Math.random()*6)];el.style.left=Math.random()*100+"vw";el.style.animationDuration=(3+Math.random()*4)+"s";el.style.fontSize=(15+Math.random()*23)+"px";document.body.appendChild(el);setTimeout(()=>el.remove(),7500)}};
  const surprise=()=>{setGift(true);rain(75);notify("A thousand little hugs for you, Lamiya! 💗")};
  const share=async()=>{const data={title:"A little surprise for Lamiya",text:"Someone made a little universe of love for you 💗",url:location.href};try{if(navigator.share)await navigator.share(data);else{await navigator.clipboard.writeText(location.href);notify("Website link copied! 💌")}}catch(e){}};
  const toggleMusic=()=>{if(!window.loveAudio){const Ctx=window.AudioContext||window.webkitAudioContext;if(!Ctx){notify("Audio is not supported in this browser");return}const ctx=new Ctx();const master=ctx.createGain();master.gain.value=.035;master.connect(ctx.destination);const notes=[523.25,659.25,783.99,659.25,587.33,698.46,880,698.46];let index=0;const play=()=>{if(!window.lovePlaying)return;const osc=ctx.createOscillator(),g=ctx.createGain();osc.type="sine";osc.frequency.value=notes[index++%notes.length];g.gain.setValueAtTime(.0001,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.6,ctx.currentTime+.08);g.gain.exponentialRampToValueAtTime(.0001,ctx.currentTime+.65);osc.connect(g);g.connect(master);osc.start();osc.stop(ctx.currentTime+.7);window.loveTimer=setTimeout(play,620)};window.loveAudio={ctx};window.lovePlay=play;}if(music){window.lovePlaying=false;clearTimeout(window.loveTimer);setMusic(false)}else{window.loveAudio.ctx.resume();window.lovePlaying=true;window.lovePlay();setMusic(true)}};
  const quizChoices=["Your smile 💗","Your kindness 🌷","Your laugh ✨","Every little thing about you 💞"];

  return <div>
    <nav className="topbar"><a className="brand" href="#">For Lamiya ♡</a><div className="nav-actions"><button className="icon-btn" title="Toggle theme" onClick={()=>setLight(!light)}>{light?"🌙":"☀️"}</button><button className="icon-btn" title="Play melody" onClick={toggleMusic}>{music?"♫":"♪"}</button><button className="icon-btn" title="Share" onClick={share}>↗</button></div></nav>
    <header className="hero"><div className="stars"></div><div className="hero-content">
      <div className="eyebrow">A little universe made just for you</div><h1>Happy Birthday<br/>Lamiya</h1>
      <p className="hero-sub">If I could wrap the stars and give them to you, I would. Until then, here's a tiny universe filled with all the love I can put into a page.</p>
      <div className="date-pill">✦ November 14 · Your special day ✦</div>
      <div className="hero-buttons"><a className="btn" href="#surprise">Explore your surprise ✨</a><button className="btn secondary" onClick={()=>{rain(35);notify("Sending you endless love 💗")}}>Send some hearts ♡</button></div>
    </div><div className="scroll-hint">Scroll to feel the love ↓</div></header>

    <section id="surprise"><div className="container"><div className="section-title reveal"><div className="eyebrow">A message from the heart</div><h2>Today, the world celebrates you</h2><p>And I get one more reason to be grateful that someone as lovely as you exists.</p></div><div className="intro-card reveal"><div className="big-heart">💗</div><p>Lamiya, I hope life gives you a thousand reasons to smile, dreams that come true one by one, and people who remind you every day how special you are. You deserve gentle days, beautiful surprises, and happiness that stays.</p><button className="btn" onClick={()=>{setLetterOpen(!letterOpen);rain(18)}}>{letterOpen?"Close my little note":"There's a note for you 💌"}</button>{letterOpen&&<p className="reveal visible">If this page could hug you, it would hold you a little longer. Happy Birthday, beautiful soul. ❤️</p>}</div></div></section>

    <section><div className="container"><div className="section-title reveal"><div className="eyebrow">The Lamiya collection</div><h2>Five little reasons to smile</h2><p>Tap any picture to see it a little closer. Every photo has its own kind of magic.</p></div><div className="gallery">{photos.map((p,i)=><div className="photo-card reveal" key={p.src} onClick={()=>setModal(p.src)}><img src={p.src} alt={"Lamiya portrait "+(i+1)} loading="lazy"/><div className="photo-caption">{p.caption}</div></div>)}</div></div></section>

    <section><div className="container"><div className="section-title reveal"><div className="eyebrow">A letter, just for you</div><h2>Read this whenever you need a smile</h2></div><div className="letter-wrap reveal"><article className="letter"><h3>My dearest Lamiya,</h3><p>Happy Birthday, meri jaan. ❤️</p><p>I may not always find the perfect words, but I hope you always know this: your happiness matters, your dreams matter, and you matter more than you can imagine. Your smile can turn an ordinary moment into a beautiful memory.</p><p>On your special day, I pray that your heart stays peaceful, your path becomes brighter, and every good thing you quietly wish for finds its way to you. May you always be surrounded by kindness, laughter, and love.</p><p>Never stop being the wonderful person you are. Keep shining in your own way. The world is more beautiful with you in it.</p><div className="signature">With all my love, always ♡</div></article></div></div></section>

    <section className="poem"><div className="container reveal"><div className="eyebrow">A little poetry for you</div><blockquote>“Tumhari hansi se roshan meri har shaam rahe,<br/>Tum khush raho, bas labon par yehi dua rahe.<br/>Har khwab tumhara haqeeqat ban kar aaye,<br/>Tumhari zindagi mein sirf khushiyon ka naam rahe.”</blockquote><div className="translation">A small wish: may your life always be filled with happiness.</div></div></section>

    <section><div className="container"><div className="section-title reveal"><div className="eyebrow">A little birthday clock</div><h2>Counting down to your day</h2><p>Every second is another reason to celebrate you.</p><div className="countdown-grid">{Object.entries(seconds).map(([k,v])=><div className="time-box" key={k}><strong>{v}</strong><span>{{d:"Days",h:"Hours",m:"Minutes",s:"Seconds"}[k]}</span></div>)}</div></div></div></section>

    <section className="gift-area"><div className="container reveal"><div className="section-title"><div className="eyebrow">A tiny birthday gift</div><h2>There's something inside...</h2><p>Go on, tap the gift. I made it just for you.</p></div><button className={"gift "+(gift?"open":"")} onClick={surprise} aria-label="Open birthday gift">{gift?"💝":"🎁"}</button><div className="gift-note">{gift?"Surprise! You are loved more than all the stars in this sky. 💗":"Tap the gift to open your surprise"}</div></div></section>

    <section><div className="container"><div className="section-title reveal"><div className="eyebrow">One tiny question</div><h2>What makes you so special?</h2><p>Choose the answer you think I would give. (Hint: there's no wrong answer.)</p></div><div className="quiz reveal"><h3>What is my favourite thing about you, Lamiya?</h3><div className="answers">{quizChoices.map(c=><button key={c} className={"answer "+(answer===c?"selected":"")} onClick={()=>{setAnswer(c);rain(12)}}>{c}</button>)}</div><div className="quiz-result">{answer?`Correct answer: every little thing about you. ${answer} is just one part of your magic. 💗`:"Choose one, birthday girl ✨"}</div></div></div></section>

    <section className="final"><div className="container reveal"><div className="big-final">🌙 ✨ 💗</div><div className="eyebrow">One last thing</div><h2>Keep shining, Lamiya</h2><p>May this new chapter bring you more joy than you can count,<br/>more love than you can imagine, and memories you'll treasure forever.</p><button className="btn" onClick={surprise}>Make the sky rain hearts 💞</button></div></section>
    <footer className="footer">Made with <span>♥</span> and a whole lot of love · For Lamiya, always ♡</footer>

    {modal&&<div className="modal" onClick={()=>setModal(null)}><button className="icon-btn modal-close" onClick={()=>setModal(null)}>✕</button><img src={modal} alt="Lamiya portrait enlarged"/></div>}
    {toast&&<div className="toast">{toast}</div>}
  </div>
}
ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
