LAMIYA — ULTIMATE BIRTHDAY WEBSITE

Files:
- index.html
- style.css
- app.js (React 18 via CDN + JavaScript)
- images/ (5 supplied photos)

Preview:
Open index.html in a browser while connected to the internet (React/Babel and Google Fonts load from CDNs).

Publish on GitHub Pages:
1. Create a PUBLIC repository, e.g. lamiya-birthday.
2. Upload index.html, style.css, app.js and the complete images folder (keep paths unchanged).
3. Open repository Settings > Pages.
4. Under Build and deployment choose Deploy from a branch.
5. Select branch main and folder /(root), then Save.
6. Wait for GitHub Pages to publish; the live URL appears on the Pages settings screen.

Notes:
- Birthday countdown targets the next November 14.
- The melody is generated in-browser with Web Audio (no copyrighted music file).
- All interactions work on a static GitHub Pages site. Internet is needed for the React/Babel CDN and fonts.
